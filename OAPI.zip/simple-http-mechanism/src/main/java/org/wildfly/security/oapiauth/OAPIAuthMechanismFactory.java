
package org.wildfly.security.oapiauth;

import java.util.Map;

import javax.security.auth.callback.CallbackHandler;

import org.wildfly.security.http.HttpAuthenticationException;
import org.wildfly.security.http.HttpServerAuthenticationMechanism;
import org.wildfly.security.http.HttpServerAuthenticationMechanismFactory;

public class OAPIAuthMechanismFactory implements HttpServerAuthenticationMechanismFactory 
{
    static final String CUSTOM_NAME = "CUSTOM_MECHANISM";

    public HttpServerAuthenticationMechanism createAuthenticationMechanism(String name, Map<String, ?> properties, CallbackHandler handler) throws HttpAuthenticationException {
        if (CUSTOM_NAME.equals(name)) {
            return new OAPIAuthHeaderHttpAuthenticationMechanism(handler);
        }
        return null;
    }

    public String[] getMechanismNames(Map<String, ?> properties) {
        return new String[] { CUSTOM_NAME };
    }
}
