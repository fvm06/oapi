package org.wildfly.security.oapiauth;

import static org.wildfly.security.oapiauth.OAPIAuthMechanismFactory.CUSTOM_NAME;

import java.io.IOException;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.Base64;

import javax.security.auth.callback.Callback;
import javax.security.auth.callback.CallbackHandler;
import javax.security.auth.callback.NameCallback;
import javax.security.auth.callback.UnsupportedCallbackException;
import javax.security.sasl.AuthorizeCallback;
import org.wildfly.security.auth.callback.AuthenticationCompleteCallback;

import org.wildfly.security.auth.callback.EvidenceVerifyCallback;
import org.wildfly.security.evidence.PasswordGuessEvidence;
import org.wildfly.security.http.HttpAuthenticationException;
import org.wildfly.security.http.HttpConstants;
import org.wildfly.security.http.HttpServerAuthenticationMechanism;
import org.wildfly.security.http.HttpServerMechanismsResponder;
import org.wildfly.security.http.HttpServerRequest;
import org.wildfly.security.http.HttpServerResponse;

class OAPIAuthHeaderHttpAuthenticationMechanism implements HttpServerAuthenticationMechanism {

    //welcom to Basic auth
    private final HttpServerMechanismsResponder respWWWAuthenticate = (HttpServerResponse response) -> {
        response.addResponseHeader(HttpConstants.WWW_AUTHENTICATE,"Basic realm=\"User Visible Realm\" charset=\"UTF-8\"");
        response.setStatusCode(401);
    };

    private final CallbackHandler callbackHandler;
    //init callbackHandler 
    OAPIAuthHeaderHttpAuthenticationMechanism(final CallbackHandler callbackHandler) {
        this.callbackHandler = callbackHandler;
    }

    //evaluate request
    @Override
    public void evaluateRequest(HttpServerRequest request) throws HttpAuthenticationException {
        String username =null;
        String password =null;
        String authHeader = request.getFirstRequestHeaderValue(HttpConstants.AUTHORIZATION);
        if(authHeader!=null){
           Integer startHValueIndex = authHeader.indexOf("Basic ");
           if (startHValueIndex!=-1){
                startHValueIndex=startHValueIndex+"Basic ".length();
                String headerValue = decodeBase64(authHeader.substring(startHValueIndex, authHeader.length()).getBytes());
                Integer sepIndex = headerValue.indexOf(":");
                if(sepIndex!=-1){
                    username= headerValue.substring(0, sepIndex);
                    password= headerValue.substring(sepIndex+1, headerValue.length());
                }
            }
        }
        
        //there are no auth headers 
        if (username == null || username.length() == 0 || password == null || password.length() == 0) {
            request.authenticationFailed("Server expects the client to send username and password",respWWWAuthenticate);
            return;
        }

        //authentication
        NameCallback nameCallback = new NameCallback("Remote Authentication Name", username);
        nameCallback.setName(username);
        //set identity password
        final PasswordGuessEvidence evidence = new PasswordGuessEvidence(password.toCharArray());
        EvidenceVerifyCallback evidenceVerifyCallback = new EvidenceVerifyCallback(evidence);
        //send name and password to provider
        handleCallback(new Callback[]{nameCallback, evidenceVerifyCallback});
        //validate identity - username / password validation
        if (evidenceVerifyCallback.isVerified() == false) {
            request.authenticationFailed("Username / Password Validation Failed");
            return;
        }
       
        //authorization
        AuthorizeCallback authorizeCallback = new AuthorizeCallback(username, username);
        handleCallback(new Callback[]{authorizeCallback});
        if (authorizeCallback.isAuthorized()) {
            handleCallback(new Callback[]{AuthenticationCompleteCallback.SUCCEEDED});
            request.authenticationComplete();
        } else {
            handleCallback(new Callback[]{AuthenticationCompleteCallback.FAILED});
            request.authenticationFailed("Authorization check failed");
        }
        return;
    }
    
   
    //to Base64
    public String encodeBase64(byte[] data) {
        byte[] encoded = Base64.getEncoder().withoutPadding().encode(data);
  	return new String(encoded, StandardCharsets.UTF_8);
    }
    //to string
    public String decodeBase64(byte[] data) {		
	byte[] decoded=Base64.getDecoder().decode(data);
	return new String(decoded, StandardCharsets.UTF_8);
    }
    
    private void handleCallback(Callback[] callback) throws HttpAuthenticationException {
        try {
            callbackHandler.handle(callback);
        } catch (IOException | UnsupportedCallbackException e) {
            throw new HttpAuthenticationException(e);
        }
     }
    
    @Override
    public String getMechanismName() {
        return CUSTOM_NAME;
    }

}
