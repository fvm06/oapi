package org.wildfly.security.oapiauth;


import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.util.Base64;

import javax.security.auth.callback.Callback;
import javax.security.auth.callback.CallbackHandler;
import javax.security.auth.callback.NameCallback;
import javax.security.auth.callback.UnsupportedCallbackException;
import javax.security.sasl.AuthorizeCallback;
import org.wildfly.security.auth.callback.AuthenticationCompleteCallback;

import org.wildfly.security.auth.callback.EvidenceVerifyCallback;
import org.wildfly.security.evidence.PasswordGuessEvidence;
import org.wildfly.security.http.HttpAuthenticationException;
import org.wildfly.security.http.HttpConstants;
import org.wildfly.security.http.HttpServerAuthenticationMechanism;
import org.wildfly.security.http.HttpServerMechanismsResponder;
import org.wildfly.security.http.HttpServerRequest;
import org.wildfly.security.http.HttpServerResponse;
import static org.wildfly.security.oapiauth.OAPIAuthMechanismFactory.OAPIAUTH_BASIC_NAME;

class OAPIAuthBasicHttpAuthenticationMechanism implements HttpServerAuthenticationMechanism {

    //welcom to Basic auth
    private final HttpServerMechanismsResponder respWWWAuthenticate = (HttpServerResponse response) -> {
        response.addResponseHeader(HttpConstants.WWW_AUTHENTICATE,"Basic realm=\"User Visible Realm\" charset=\"UTF-8\"");
        response.setStatusCode(401);
    };
    
    //welcom to Basic auth
    private final HttpServerMechanismsResponder respBearer = (HttpServerResponse response) -> {
        response.addResponseHeader(HttpConstants.BEARER_TOKEN,"Bearer token");
        response.setStatusCode(200);
    };

    private final CallbackHandler callbackHandler;
    //init callbackHandler 
    OAPIAuthBasicHttpAuthenticationMechanism(final CallbackHandler callbackHandler) {
        this.callbackHandler = callbackHandler;
    }

    //evaluate request
    @Override
    public void evaluateRequest(HttpServerRequest request) throws HttpAuthenticationException {
        String username =null;
        String password =null;
        String authHeader = request.getFirstRequestHeaderValue(HttpConstants.AUTHORIZATION);
        
        
        InetSocketAddress inetSocketAddress = request.getSourceAddress();
        String sourceHost = inetSocketAddress.getHostString();
        
        
        if(authHeader!=null){
           Integer startHValueIndex = authHeader.indexOf("Basic ");
           if (startHValueIndex!=-1){
                startHValueIndex=startHValueIndex+"Basic ".length();
                String headerValue = decodeBase64(authHeader.substring(startHValueIndex, authHeader.length()).getBytes());
                Integer sepIndex = headerValue.indexOf(":");
                if(sepIndex!=-1){
                    username= headerValue.substring(0, sepIndex);
                    password= headerValue.substring(sepIndex+1, headerValue.length());
                }
            }else{
                //mechanism is not able to auth this request
                request.noAuthenticationInProgress();  
                return;
            }
         }
        
        //there are no auth headers 
        if (username == null || username.length() == 0 || password == null || password.length() == 0) {
            request.authenticationFailed("Server expects the client to send username and password",respWWWAuthenticate);
            return;
        }

        //send principal name to framework
        NameCallback nameCallback = new NameCallback("Remote Authentication Name", username);
        nameCallback.setName(username);
        //set identity password
        final PasswordGuessEvidence evidence = new PasswordGuessEvidence(password.toCharArray());
        EvidenceVerifyCallback evidenceVerifyCallback = new EvidenceVerifyCallback(evidence);
        //send name and password to framework
        handleCallback(new Callback[]{nameCallback, evidenceVerifyCallback});
        //get identity from realm and validate - username / password validation
        if (evidenceVerifyCallback.isVerified() == false) {
            request.authenticationFailed("Username / Password Validation Failed");
            return;
        }
       
        //set security context
        AuthorizeCallback authorizeCallback = new AuthorizeCallback(username, username);
        handleCallback(new Callback[]{authorizeCallback});
        if (authorizeCallback.isAuthorized()) {
            handleCallback(new Callback[]{AuthenticationCompleteCallback.SUCCEEDED});
            request.authenticationComplete();
        } else {
            handleCallback(new Callback[]{AuthenticationCompleteCallback.FAILED});
            request.authenticationFailed("Authorization check failed");
        }
        return;
    }
    
    //to Base64
    public String encodeBase64(byte[] data) {
        byte[] encoded = Base64.getEncoder().withoutPadding().encode(data);
  	return new String(encoded, StandardCharsets.UTF_8);
    }
    //from Base64
    public String decodeBase64(byte[] data) {		
	byte[] decoded=Base64.getDecoder().decode(data);
	return new String(decoded, StandardCharsets.UTF_8);
    }
    
    //send callback to framework
    private void handleCallback(Callback[] callback) throws HttpAuthenticationException {
        try {
            callbackHandler.handle(callback);
        } catch (IOException | UnsupportedCallbackException e) {
            throw new HttpAuthenticationException(e);
        }
     }
    
    @Override
    //reg mechanism
    public String getMechanismName() {
        return OAPIAUTH_BASIC_NAME;
    }
}
