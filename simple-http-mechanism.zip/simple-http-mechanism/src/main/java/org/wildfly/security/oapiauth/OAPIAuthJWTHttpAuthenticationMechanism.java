package org.wildfly.security.oapiauth;

import java.io.IOException;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.security.auth.callback.Callback;
import javax.security.auth.callback.CallbackHandler;
import javax.security.auth.callback.NameCallback;
import javax.security.auth.callback.UnsupportedCallbackException;
import javax.security.sasl.AuthorizeCallback;
import org.wildfly.security.auth.callback.AuthenticationCompleteCallback;

import org.wildfly.security.auth.callback.EvidenceVerifyCallback;
import org.wildfly.security.auth.callback.IdentityCredentialCallback;
import org.wildfly.security.auth.callback.PeerPrincipalCallback;
//import org.wildfly.security.auth.principal.NamePrincipal;
import org.wildfly.security.auth.principal.RealmNestedPrincipal;
import org.wildfly.security.credential.BearerTokenCredential;
import org.wildfly.security.evidence.BearerTokenEvidence;
import org.wildfly.security.evidence.PasswordGuessEvidence;
import org.wildfly.security.http.HttpAuthenticationException;
import org.wildfly.security.http.HttpConstants;
import org.wildfly.security.http.HttpServerAuthenticationMechanism;
import org.wildfly.security.http.HttpServerMechanismsResponder;
import org.wildfly.security.http.HttpServerRequest;
import org.wildfly.security.http.HttpServerResponse;
import static org.wildfly.security.oapiauth.OAPIAuthMechanismFactory.OAPIAUT_JWT_NAME;


class OAPIAuthJWTHttpAuthenticationMechanism implements HttpServerAuthenticationMechanism {

    private static final Pattern BEARER_TOKEN_PATTERN = Pattern.compile("^Bearer *([^ ]+) *$", Pattern.CASE_INSENSITIVE);


    private final CallbackHandler callbackHandler;
    
    //init callbackHandler 
    OAPIAuthJWTHttpAuthenticationMechanism(final CallbackHandler callbackHandler) {
        this.callbackHandler = callbackHandler;
    }

    //evaluate request
    @Override
    public void evaluateRequest(HttpServerRequest request) throws HttpAuthenticationException {
        List<String> authorizationValues = request.getRequestHeaderValues("Authorization");

        if (authorizationValues == null || authorizationValues.isEmpty()) {
            request.authenticationFailed("Bearer token required", response -> response.setStatusCode(401));
            return;
        } else if (authorizationValues.size() > 1) {
            request.authenticationFailed("Multiple Authorization headers found", response -> response.setStatusCode(400));
            return;
        }

        String authorizationValue = authorizationValues.get(0);
        Matcher matcher = BEARER_TOKEN_PATTERN.matcher(authorizationValue);

        if (!matcher.matches()) {
            request.authenticationFailed("Authorization is not Bearer", response -> response.setStatusCode(400));
            return;
        }

        BearerTokenEvidence tokenEvidence = new BearerTokenEvidence(matcher.group(1));
        EvidenceVerifyCallback verifyCallback = new EvidenceVerifyCallback(tokenEvidence);

        handleCallback(new Callback[]{verifyCallback});

        if (verifyCallback.isVerified()) {
            AuthorizeCallback authorizeCallback = new AuthorizeCallback(null, null);

            handleCallback(new Callback[]{authorizeCallback});

            if (authorizeCallback.isAuthorized()) {
                IdentityCredentialCallback identityCredentialCallback = new IdentityCredentialCallback(new BearerTokenCredential(tokenEvidence.getToken()), true);
                handleCallback(new Callback[]{identityCredentialCallback});
                handleCallback(new Callback[]{AuthenticationCompleteCallback.SUCCEEDED});
                request.authenticationComplete();
                return;
            }
        }

        request.authenticationFailed("Invalid bearer token", response -> response.setStatusCode(403));
    }

    
    //to Base64
    public String encodeBase64(byte[] data) {
        byte[] encoded = Base64.getEncoder().withoutPadding().encode(data);
  	return new String(encoded, StandardCharsets.UTF_8);
    }
    //to string
    public String decodeBase64(byte[] data) {		
	byte[] decoded=Base64.getDecoder().decode(data);
	return new String(decoded, StandardCharsets.UTF_8);
    }
    
    private void handleCallback(Callback[] callback) throws HttpAuthenticationException {
        try {
            callbackHandler.handle(callback);
        } catch (IOException | UnsupportedCallbackException e) {
            throw new HttpAuthenticationException(e);
        }
     }
    
    @Override
    public String getMechanismName() {
        return OAPIAUT_JWT_NAME;
    }

}
