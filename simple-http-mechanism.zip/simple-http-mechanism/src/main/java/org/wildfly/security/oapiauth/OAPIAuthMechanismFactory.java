
package org.wildfly.security.oapiauth;

import java.util.Map;

import javax.security.auth.callback.CallbackHandler;

import org.wildfly.security.http.HttpAuthenticationException;
import org.wildfly.security.http.HttpServerAuthenticationMechanism;
import org.wildfly.security.http.HttpServerAuthenticationMechanismFactory;

public class OAPIAuthMechanismFactory implements HttpServerAuthenticationMechanismFactory 
{
    static final String OAPIAUTH_BASIC_NAME = "OAPIAUTH_BASIC_MECHANISM";
    static final String OAPIAUT_JWT_NAME = "OAPIAUTH_JWT_MECHANISM";

    public HttpServerAuthenticationMechanism createAuthenticationMechanism(String name, Map<String, ?> properties, CallbackHandler handler) throws HttpAuthenticationException {
        if (OAPIAUTH_BASIC_NAME.equals(name)) {
            return new OAPIAuthBasicHttpAuthenticationMechanism(handler);
        }
        if (OAPIAUT_JWT_NAME.equals(name)) {
            return new OAPIAuthJWTHttpAuthenticationMechanism(handler);
        }
        return null;
    }

    public String[] getMechanismNames(Map<String, ?> properties) {
        return new String[] { OAPIAUTH_BASIC_NAME, OAPIAUT_JWT_NAME };
    }
}
